<?php

	require('server_processing.php');

	echo $row;

?>